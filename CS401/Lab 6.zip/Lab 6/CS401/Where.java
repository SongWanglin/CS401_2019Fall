package CS401;
   /*
    * Where do we want to add elements?
    */
   public enum Where { FRONT, BACK, MIDDLE };

