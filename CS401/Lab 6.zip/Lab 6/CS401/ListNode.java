package CS401;

public class ListNode {
	Employee val;
	ListNode next;
	ListNode(Employee x) { val = x; }
}