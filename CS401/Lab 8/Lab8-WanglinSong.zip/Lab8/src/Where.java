
public enum Where {
	FRONT, MIDDLE, REAR;
}
