package CS401;

public class ListNode {
	Object val;
	ListNode next;
	ListNode(Object x) { val = x; }
}